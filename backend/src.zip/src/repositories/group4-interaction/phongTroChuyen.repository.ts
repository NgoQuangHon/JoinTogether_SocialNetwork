import { pool } from "../../config/db";
import { PhongTroChuyen } from "../../models/group4-interaction/phongTroChuyen.model";

export class PhongTroChuyenRepository {
  async create(data: Partial<PhongTroChuyen>): Promise<PhongTroChuyen> {
    const query = `
      INSERT INTO phong_tro_chuyen (hoat_dong_id, ten_phong, loai_phong, trang_thai)
      VALUES ($1, $2, $3, $4)
      RETURNING
        phong_id AS "phongId",
        hoat_dong_id AS "hoatDongId",
        ten_phong AS "tenPhong",
        loai_phong AS "loaiPhong",
        trang_thai AS "trangThai",
        ngay_tao AS "ngayTao"
    `;
    const result = await pool.query(query, [
      data.hoatDongId,
      data.tenPhong === undefined || data.tenPhong === null ? null : data.tenPhong,
      data.loaiPhong === undefined || data.loaiPhong === null ? 'NHOM' : data.loaiPhong,
      data.trangThai === undefined || data.trangThai === null ? 'ACTIVE' : data.trangThai,
    ]);
    return result.rows[0];
  }

  async findById(id: number): Promise<PhongTroChuyen | null> {
    const query = `
      SELECT
        phong_id AS "phongId",
        hoat_dong_id AS "hoatDongId",
        ten_phong AS "tenPhong",
        loai_phong AS "loaiPhong",
        trang_thai AS "trangThai",
        ngay_tao AS "ngayTao",
        het_han_luc AS "hetHanLuc"
      FROM phong_tro_chuyen
      WHERE phong_id = $1
    `;
    const result = await pool.query(query, [id]);
    return result.rows.length > 0 ? result.rows[0] : null;
  }

  async findByHoatDongId(hoatDongId: number): Promise<PhongTroChuyen | null> {
    const query = `
      SELECT
        phong_id AS "phongId",
        hoat_dong_id AS "hoatDongId",
        ten_phong AS "tenPhong",
        loai_phong AS "loaiPhong",
        trang_thai AS "trangThai",
        ngay_tao AS "ngayTao"
      FROM phong_tro_chuyen
      WHERE hoat_dong_id = $1
    `;
    const result = await pool.query(query, [hoatDongId]);
    return result.rows.length > 0 ? result.rows[0] : null;
  }

  async findRoomsByUser(nguoiDungId: number): Promise<any[]> {
    const query = `
      SELECT DISTINCT
        pt.phong_id AS "phongId",
        pt.hoat_dong_id AS "hoatDongId",
        hd.ten_hoat_dong AS "tenHoatDong",
        CASE 
          WHEN pt.loai_phong = 'RIENG_TU' THEN (
            SELECT nd.ho_ten 
            FROM thanh_vien_phong tvp2 
            JOIN nguoi_dung nd ON tvp2.nguoi_dung_id = nd.nguoi_dung_id 
            WHERE tvp2.phong_id = pt.phong_id AND tvp2.nguoi_dung_id != $1 
            LIMIT 1
          )
          ELSE pt.ten_phong 
        END AS "tenPhong",
        (
          SELECT tvp2.nguoi_dung_id 
          FROM thanh_vien_phong tvp2 
          WHERE tvp2.phong_id = pt.phong_id AND tvp2.nguoi_dung_id != $1 
          LIMIT 1
        ) AS "otherUserId",
        pt.loai_phong AS "loaiPhong",
        pt.trang_thai AS "trangThai",
        pt.ngay_tao AS "ngayTao",
        pt.het_han_luc AS "hetHanLuc",
        EXISTS (
          SELECT 1 FROM quan_he_ket_noi qhk
          WHERE ((qhk.nguoi_dung_id_1 = $1 AND qhk.nguoi_dung_id_2 = (
            SELECT tvp2.nguoi_dung_id FROM thanh_vien_phong tvp2 WHERE tvp2.phong_id = pt.phong_id AND tvp2.nguoi_dung_id != $1 LIMIT 1
          )) OR (qhk.nguoi_dung_id_2 = $1 AND qhk.nguoi_dung_id_1 = (
            SELECT tvp2.nguoi_dung_id FROM thanh_vien_phong tvp2 WHERE tvp2.phong_id = pt.phong_id AND tvp2.nguoi_dung_id != $1 LIMIT 1
          ))) AND qhk.trang_thai = 'ACTIVE'
        ) AS "isFriend",
        COALESCE((
          SELECT trang_thai FROM de_xuat_ket_ban WHERE phong_id = pt.phong_id AND nguoi_dung_id = $1 LIMIT 1
        ), 'NONE') AS "myProposal",
        COALESCE((
          SELECT trang_thai FROM de_xuat_ket_ban WHERE phong_id = pt.phong_id AND nguoi_dung_id != $1 LIMIT 1
        ), 'NONE') AS "otherProposal",
        (SELECT COUNT(*) FROM tin_nhan tn WHERE tn.phong_id = pt.phong_id) AS "soLuongTinNhan"
      FROM phong_tro_chuyen pt
      LEFT JOIN hoat_dong hd ON pt.hoat_dong_id = hd.hoat_dong_id
      LEFT JOIN thanh_vien_hoat_dong tv ON tv.hoat_dong_id = pt.hoat_dong_id
      LEFT JOIN thanh_vien_phong tvp ON tvp.phong_id = pt.phong_id
      WHERE (hd.nguoi_to_chuc_id = $1 OR tv.nguoi_dung_id = $1 OR tvp.nguoi_dung_id = $1)
        AND pt.trang_thai = 'ACTIVE'
      ORDER BY pt.ngay_tao DESC
    `;
    const result = await pool.query(query, [nguoiDungId]);
    return result.rows;
  }

  async update(id: number, data: Partial<PhongTroChuyen>): Promise<PhongTroChuyen | null> {
    const setClauses: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    if (data.tenPhong !== undefined) {
      setClauses.push(`ten_phong = $${paramIndex++}`);
      values.push(data.tenPhong);
    }
    if (data.loaiPhong !== undefined) {
      setClauses.push(`loai_phong = $${paramIndex++}`);
      values.push(data.loaiPhong);
    }
    if (data.trangThai !== undefined) {
      setClauses.push(`trang_thai = $${paramIndex++}`);
      values.push(data.trangThai);
    }

    if (setClauses.length === 0) return this.findById(id);

    values.push(id);
    const query = `
      UPDATE phong_tro_chuyen
      SET ${setClauses.join(", ")}
      WHERE phong_id = $${paramIndex}
      RETURNING
        phong_id AS "phongId",
        hoat_dong_id AS "hoatDongId",
        ten_phong AS "tenPhong",
        loai_phong AS "loaiPhong",
        trang_thai AS "trangThai",
        ngay_tao AS "ngayTao"
    `;
    const result = await pool.query(query, values);
    return result.rows.length > 0 ? result.rows[0] : null;
  }
}
